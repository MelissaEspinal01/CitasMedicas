﻿namespace CitasMedicas
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.listacmb = new System.Windows.Forms.ComboBox();
            this.doctorbtnag = new System.Windows.Forms.Button();
            this.doctortxt = new System.Windows.Forms.TextBox();
            this.pacientetxt = new System.Windows.Forms.TextBox();
            this.asignadocmb = new System.Windows.Forms.ComboBox();
            this.pacientebtnag = new System.Windows.Forms.Button();
            this.verbtn = new System.Windows.Forms.Button();
            this.fechatxt = new System.Windows.Forms.TextBox();
            this.motivocheck = new System.Windows.Forms.CheckedListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.estadocmb = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pendientecheck = new System.Windows.Forms.CheckBox();
            this.finalizadacheck = new System.Windows.Forms.CheckBox();
            this.canceladacheck = new System.Windows.Forms.CheckBox();
            this.aceptarbtn = new System.Windows.Forms.Button();
            this.datosgrid = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.datosgrid)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Aquamarine;
            this.label1.Font = new System.Drawing.Font("Gill Sans MT", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(485, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(192, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "Citas Médicas";
            // 
            // listacmb
            // 
            this.listacmb.FormattingEnabled = true;
            this.listacmb.Location = new System.Drawing.Point(860, 150);
            this.listacmb.Name = "listacmb";
            this.listacmb.Size = new System.Drawing.Size(166, 21);
            this.listacmb.TabIndex = 1;
            // 
            // doctorbtnag
            // 
            this.doctorbtnag.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doctorbtnag.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.doctorbtnag.Location = new System.Drawing.Point(97, 200);
            this.doctorbtnag.Name = "doctorbtnag";
            this.doctorbtnag.Size = new System.Drawing.Size(153, 64);
            this.doctorbtnag.TabIndex = 2;
            this.doctorbtnag.Text = "Agregar Doctor";
            this.doctorbtnag.UseVisualStyleBackColor = true;
            this.doctorbtnag.Click += new System.EventHandler(this.doctorbtnag_Click);
            // 
            // doctortxt
            // 
            this.doctortxt.Location = new System.Drawing.Point(45, 118);
            this.doctortxt.Multiline = true;
            this.doctortxt.Name = "doctortxt";
            this.doctortxt.Size = new System.Drawing.Size(264, 53);
            this.doctortxt.TabIndex = 3;
            // 
            // pacientetxt
            // 
            this.pacientetxt.Location = new System.Drawing.Point(45, 310);
            this.pacientetxt.Multiline = true;
            this.pacientetxt.Name = "pacientetxt";
            this.pacientetxt.Size = new System.Drawing.Size(264, 61);
            this.pacientetxt.TabIndex = 5;
            // 
            // asignadocmb
            // 
            this.asignadocmb.FormattingEnabled = true;
            this.asignadocmb.Location = new System.Drawing.Point(45, 490);
            this.asignadocmb.Name = "asignadocmb";
            this.asignadocmb.Size = new System.Drawing.Size(264, 21);
            this.asignadocmb.TabIndex = 6;
            // 
            // pacientebtnag
            // 
            this.pacientebtnag.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pacientebtnag.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.pacientebtnag.Location = new System.Drawing.Point(92, 529);
            this.pacientebtnag.Name = "pacientebtnag";
            this.pacientebtnag.Size = new System.Drawing.Size(160, 64);
            this.pacientebtnag.TabIndex = 7;
            this.pacientebtnag.Text = "Agregar Paciente";
            this.pacientebtnag.UseVisualStyleBackColor = true;
            this.pacientebtnag.Click += new System.EventHandler(this.pacientebtnag_Click);
            // 
            // verbtn
            // 
            this.verbtn.Location = new System.Drawing.Point(883, 216);
            this.verbtn.Name = "verbtn";
            this.verbtn.Size = new System.Drawing.Size(121, 64);
            this.verbtn.TabIndex = 8;
            this.verbtn.Text = "Ver";
            this.verbtn.UseVisualStyleBackColor = true;
            this.verbtn.Click += new System.EventHandler(this.verbtn_Click);
            // 
            // fechatxt
            // 
            this.fechatxt.Location = new System.Drawing.Point(45, 403);
            this.fechatxt.Multiline = true;
            this.fechatxt.Name = "fechatxt";
            this.fechatxt.Size = new System.Drawing.Size(264, 43);
            this.fechatxt.TabIndex = 9;
            // 
            // motivocheck
            // 
            this.motivocheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.motivocheck.FormattingEnabled = true;
            this.motivocheck.Items.AddRange(new object[] {
            "Dolor de cabeza",
            "Fiebre",
            "Gripe",
            "Dolor estomacal",
            "Problemas cardiacos",
            "DIficultad respiratoria",
            "Examenes generales",
            "Tratamiento intravenoso"});
            this.motivocheck.Location = new System.Drawing.Point(342, 403);
            this.motivocheck.Name = "motivocheck";
            this.motivocheck.Size = new System.Drawing.Size(175, 140);
            this.motivocheck.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(866, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 20);
            this.label4.TabIndex = 13;
            this.label4.Text = "Lista de doctores";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(93, 380);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(157, 20);
            this.label5.TabIndex = 14;
            this.label5.Text = "Fecha de consulta";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(93, 95);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(159, 20);
            this.label6.TabIndex = 15;
            this.label6.Text = "Nombre del Doctor";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(127, 280);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 20);
            this.label7.TabIndex = 16;
            this.label7.Text = "Paciente";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(93, 467);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(141, 20);
            this.label8.TabIndex = 17;
            this.label8.Text = "Doctor asignado";
            // 
            // estadocmb
            // 
            this.estadocmb.FormattingEnabled = true;
            this.estadocmb.Location = new System.Drawing.Point(883, 350);
            this.estadocmb.Name = "estadocmb";
            this.estadocmb.Size = new System.Drawing.Size(121, 21);
            this.estadocmb.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(913, 327);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 20);
            this.label2.TabIndex = 19;
            this.label2.Text = "Estado";
           
            // 
            // pendientecheck
            // 
            this.pendientecheck.AutoSize = true;
            this.pendientecheck.Location = new System.Drawing.Point(906, 387);
            this.pendientecheck.Name = "pendientecheck";
            this.pendientecheck.Size = new System.Drawing.Size(74, 17);
            this.pendientecheck.TabIndex = 20;
            this.pendientecheck.Text = "Pendiente";
            this.pendientecheck.UseVisualStyleBackColor = true;
            // 
            // finalizadacheck
            // 
            this.finalizadacheck.AutoSize = true;
            this.finalizadacheck.Location = new System.Drawing.Point(906, 411);
            this.finalizadacheck.Name = "finalizadacheck";
            this.finalizadacheck.Size = new System.Drawing.Size(73, 17);
            this.finalizadacheck.TabIndex = 21;
            this.finalizadacheck.Text = "Finalizada";
            this.finalizadacheck.UseVisualStyleBackColor = true;
            // 
            // canceladacheck
            // 
            this.canceladacheck.AutoSize = true;
            this.canceladacheck.Location = new System.Drawing.Point(906, 435);
            this.canceladacheck.Name = "canceladacheck";
            this.canceladacheck.Size = new System.Drawing.Size(77, 17);
            this.canceladacheck.TabIndex = 22;
            this.canceladacheck.Text = "Cancelada";
            this.canceladacheck.UseVisualStyleBackColor = true;
            // 
            // aceptarbtn
            // 
            this.aceptarbtn.Location = new System.Drawing.Point(883, 468);
            this.aceptarbtn.Name = "aceptarbtn";
            this.aceptarbtn.Size = new System.Drawing.Size(121, 62);
            this.aceptarbtn.TabIndex = 23;
            this.aceptarbtn.Text = "Aceptar";
            this.aceptarbtn.UseVisualStyleBackColor = true;
            this.aceptarbtn.Click += new System.EventHandler(this.aceptarbtn_Click);
            // 
            // datosgrid
            // 
            this.datosgrid.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.datosgrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datosgrid.Location = new System.Drawing.Point(417, 191);
            this.datosgrid.Name = "datosgrid";
            this.datosgrid.Size = new System.Drawing.Size(323, 156);
            this.datosgrid.TabIndex = 24;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CadetBlue;
            this.ClientSize = new System.Drawing.Size(1089, 641);
            this.Controls.Add(this.datosgrid);
            this.Controls.Add(this.aceptarbtn);
            this.Controls.Add(this.canceladacheck);
            this.Controls.Add(this.finalizadacheck);
            this.Controls.Add(this.pendientecheck);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.estadocmb);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.motivocheck);
            this.Controls.Add(this.fechatxt);
            this.Controls.Add(this.verbtn);
            this.Controls.Add(this.pacientebtnag);
            this.Controls.Add(this.asignadocmb);
            this.Controls.Add(this.pacientetxt);
            this.Controls.Add(this.doctortxt);
            this.Controls.Add(this.doctorbtnag);
            this.Controls.Add(this.listacmb);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.datosgrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox listacmb;
        private System.Windows.Forms.Button doctorbtnag;
        private System.Windows.Forms.TextBox doctortxt;
        private System.Windows.Forms.TextBox pacientetxt;
        private System.Windows.Forms.ComboBox asignadocmb;
        private System.Windows.Forms.Button pacientebtnag;
        private System.Windows.Forms.Button verbtn;
        private System.Windows.Forms.TextBox fechatxt;
        private System.Windows.Forms.CheckedListBox motivocheck;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox estadocmb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox pendientecheck;
        private System.Windows.Forms.CheckBox finalizadacheck;
        private System.Windows.Forms.CheckBox canceladacheck;
        private System.Windows.Forms.Button aceptarbtn;
        private System.Windows.Forms.DataGridView datosgrid;
    }
}

