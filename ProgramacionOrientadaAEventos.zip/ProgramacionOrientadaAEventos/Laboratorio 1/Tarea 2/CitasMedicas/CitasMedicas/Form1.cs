﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CitasMedicas;


namespace CitasMedicas
{
    public partial class Form1 : Form
    {
        private string doctoresFilePath = "doctores.txt";
        private string pacientesFilePath = "pacientes.txt";
        private List<PacienteDoctor.Doctor> doctores = new List<PacienteDoctor.Doctor>();
        private List<PacienteDoctor.Paciente> pacientes = new List<PacienteDoctor.Paciente>();


        public Form1()
        {
            InitializeComponent();
            ActualizarListaDoctores();
            ConfigurarColumnasDataGridView();
            CargarNombresPacientes();
            
        }

        private void doctorbtnag_Click(object sender, EventArgs e)
        {

            string nombreDoctor = doctortxt.Text;

            if (!string.IsNullOrWhiteSpace(nombreDoctor))
            {
                using (StreamWriter writer = File.AppendText(doctoresFilePath))
                {
                    writer.WriteLine(nombreDoctor);
                }

                
                ActualizarListaDoctores();
            }

        }
        private void ActualizarListaDoctores()
        {
           
            doctores.Clear();

          
            if (File.Exists(doctoresFilePath))
            {
                string[] nombresDoctores = File.ReadAllLines(doctoresFilePath);
                foreach (string nombreDoctor in nombresDoctores)
                {
                    PacienteDoctor.Doctor doctor = new PacienteDoctor.Doctor
                    {
                        Nombre = nombreDoctor
                    };
                    doctores.Add(doctor);
                }
            }

            
            asignadocmb.DataSource = null;
            asignadocmb.DataSource = doctores;
            asignadocmb.DisplayMember = "Nombre";

            listacmb.DataSource = null;
            listacmb.DataSource = doctores;
            listacmb.DisplayMember = "Nombre";
        }

        private void pacientebtnag_Click(object sender, EventArgs e)
        {

            string nombrePaciente = pacientetxt.Text;
            PacienteDoctor.Doctor doctorAsignado = asignadocmb.SelectedItem as PacienteDoctor.Doctor;

            
            string fechaConsulta = fechatxt.Text;

            
            List<string> motivosConsulta = new List<string>();
            foreach (object item in motivocheck.CheckedItems)
            {
                motivosConsulta.Add(item.ToString());
            }
            string motivoConsulta = string.Join(", ", motivosConsulta);

            if (!string.IsNullOrWhiteSpace(nombrePaciente) && doctorAsignado != null && motivosConsulta.Count > 0 && !string.IsNullOrWhiteSpace(fechaConsulta))
            {
                
                using (StreamWriter writer = File.AppendText(pacientesFilePath))
                {
                    writer.WriteLine($"{nombrePaciente},{doctorAsignado.Nombre},{fechaConsulta},{motivoConsulta}");
                }

                
                
            }

        }
        private void ActualizarListaPacientesDoctor(PacienteDoctor.Doctor doctor)
        {
            datosgrid.Rows.Clear();

            if (File.Exists(pacientesFilePath))
            {
                string[] datosPacientes = File.ReadAllLines(pacientesFilePath);
                foreach (string datosPaciente in datosPacientes)
                {
                    string[] partes = datosPaciente.Split(',');
                    if (partes.Length >= 4 && partes[1] == doctor.Nombre)
                    {
                        datosgrid.Rows.Add(partes[0], partes[2], partes[3]);
                    }
                }
            }
        }

        private void comboBoxDoctores_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listacmb.SelectedItem != null)
            {
                PacienteDoctor.Doctor doctorSeleccionado = listacmb.SelectedItem as PacienteDoctor.Doctor;
                ActualizarListaGrid(doctorSeleccionado);
            }
        }
        private void ActualizarListaGrid(PacienteDoctor.Doctor doctor)
        {
            datosgrid.Rows.Clear();

            if (File.Exists(pacientesFilePath))
            {
                string[] datosPacientes = File.ReadAllLines(pacientesFilePath);
                foreach (string datosPaciente in datosPacientes)
                {
                    string[] partes = datosPaciente.Split(',');
                    if (partes.Length >= 4 && partes[1] == doctor.Nombre)
                    {
                        datosgrid.Rows.Add(partes[0], partes[2], partes[3]);
                    }
                }
            }
        }

        private void ComboBoxDoctores_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listacmb.SelectedItem != null)
            {
                PacienteDoctor.Doctor doctorSeleccionado = listacmb.SelectedItem as PacienteDoctor.Doctor;
                ActualizarListaGrid(doctorSeleccionado);
            }
        }

        private void verbtn_Click(object sender, EventArgs e)
        {
            if (listacmb.SelectedItem != null)
            {
                PacienteDoctor.Doctor doctorSeleccionado = listacmb.SelectedItem as PacienteDoctor.Doctor;
                ActualizarListaPacientesDoctor(doctorSeleccionado);
            }
        }
        private void ConfigurarColumnasDataGridView()
        {
            
            datosgrid.Columns.Add("Nombre", "Nombre");
            datosgrid.Columns.Add("FechaConsulta", "Fecha Consulta");
            datosgrid.Columns.Add("MotivoConsulta", "Motivo Consulta");
            datosgrid.Columns.Add("Estado", "Estado");
        }

        private void aceptarbtn_Click(object sender, EventArgs e)
        {
            if (estadocmb.SelectedItem != null)
            {
                string nombrePaciente = estadocmb.SelectedItem.ToString();

                
                List<string> estadosConsulta = new List<string>();
                if (pendientecheck.Checked) estadosConsulta.Add("Pendiente");
                if (finalizadacheck.Checked) estadosConsulta.Add("Finalizada");
                if (canceladacheck.Checked) estadosConsulta.Add("Cancelada");
                string estadoConsulta = string.Join(", ", estadosConsulta);

                
                foreach (DataGridViewRow row in datosgrid.Rows)
                {
                    if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == nombrePaciente)
                    {
                        row.Cells[3].Value = estadoConsulta; 
                        break;
                    }
                }
            }
        }
        private void CargarNombresPacientes()
        {
            estadocmb.Items.Clear();

            if (File.Exists(pacientesFilePath))
            {
                string[] datosPacientes = File.ReadAllLines(pacientesFilePath);
                foreach (string datosPaciente in datosPacientes)
                {
                    string[] partes = datosPaciente.Split(',');
                    if (partes.Length >= 4)
                    {
                        estadocmb.Items.Add(partes[0]); 
                    }
                }
            }
        }

       
    }
}
